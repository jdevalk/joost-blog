(() => {
  'use strict';
  // Detect the document itself, not its filename: sitemap URLs need not end in .xml.
  if (!['application/xml', 'text/xml'].includes(document.contentType)) return;
  const NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const original = document.documentElement;
  // Chromium may already have placed the XML inside its built-in tree viewer.
  const source = original?.namespaceURI === NS ? original
    : document.getElementById('webkit-xml-viewer-source-xml')?.firstElementChild;
  if (!source || source.namespaceURI !== NS || !['urlset', 'sitemapindex'].includes(source.localName)) return;
  if (document.getElementsByTagName('parsererror').length) return;

  const isIndex = source.localName === 'sitemapindex';
  const itemName = isIndex ? 'sitemap' : 'url';
  const field = (element, name) => Array.from(element.children)
    .find(child => child.namespaceURI === NS && child.localName === name)?.textContent.trim() || '';
  const entries = Array.from(source.children)
    .filter(child => child.namespaceURI === NS && child.localName === itemName)
    .map(item => ({ url: field(item, 'loc'), modified: field(item, 'lastmod') }));
  const xml = new XMLSerializer().serializeToString(source);
  const safeLink = value => {
    try {
      const url = new URL(value);
      return ['https:', 'http:'].includes(url.protocol) ? url.href : null;
    } catch { return null; }
  };
  const el = (name, text, attrs = {}) => {
    const node = document.createElementNS(XHTML, name);
    if (text !== undefined) node.textContent = text;
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
    return node;
  };

  const html = el('html', undefined, { id: 'pretty-sitemap', lang: 'en' });
  const head = el('head');
  head.append(el('meta', undefined, { name: 'viewport', content: 'width=device-width, initial-scale=1' }),
    el('title', `${isIndex ? 'Sitemap index' : 'XML sitemap'} · ${location.hostname || 'Local file'}`));
  const body = el('body');
  const main = el('main');
  const header = el('header');
  header.append(el('p', 'PRETTY XML SITEMAPS', { class: 'eyebrow' }),
    el('h1', isIndex ? 'Sitemap index' : 'XML sitemap'),
    el('p', location.href, { class: 'source' }),
    el('p', isIndex ? 'Browse the sitemaps that list this site’s pages.' : 'Browse the pages listed in this sitemap.', { class: 'intro' }));
  const toggle = el('button', 'Show XML', { type: 'button', 'aria-expanded': 'false', 'aria-controls': 'xml-data' });
  header.append(toggle);
  const viewer = el('section', undefined, { 'aria-label': 'Sitemap entries' });
  const toolbar = el('div', undefined, { class: 'toolbar' });
  const label = el('label', 'Filter by address', { for: 'filter' });
  const input = el('input', undefined, { id: 'filter', type: 'search', placeholder: 'Type part of an address…', autocomplete: 'off' });
  const count = el('p', undefined, { role: 'status', 'aria-live': 'polite', class: 'count' });
  toolbar.append(label, input, count);
  const tableWrap = el('div', undefined, { class: 'table-wrap' });
  const table = el('table');
  const caption = el('caption', isIndex ? 'Sitemaps and their last modification dates' : 'Page addresses and their last modification dates', { class: 'sr-only' });
  const thead = el('thead');
  const headings = el('tr');
  headings.append(el('th', isIndex ? 'Sitemap' : 'Page address', { scope: 'col' }), el('th', 'Last modified', { scope: 'col' }));
  thead.append(headings);
  const tbody = el('tbody');
  table.append(caption, thead, tbody);
  tableWrap.append(table);
  const empty = el('p', '', { class: 'empty', hidden: '' });
  const nav = el('nav', undefined, { 'aria-label': 'Table pages', class: 'pagination' });
  const previous = el('button', 'Previous', { type: 'button' });
  const pageLabel = el('span');
  const next = el('button', 'Next', { type: 'button' });
  nav.append(previous, pageLabel, next);
  viewer.append(toolbar, tableWrap, empty, nav);
  const raw = el('pre', xml, { id: 'xml-data', hidden: '', tabindex: '0', 'aria-label': 'Sitemap XML data' });
  main.append(header, viewer, raw, el('footer', 'Displayed by Pretty XML Sitemaps. The file on the website is unchanged.'));
  body.append(main);
  html.append(head, body);
  // Drop processing instructions too, so the replacement cannot trigger an XSL transform.
  while (document.firstChild) document.removeChild(document.firstChild);
  document.appendChild(html);

  let filtered = entries;
  let page = 0;
  const pageSize = 100;
  function render() {
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, totalPages - 1);
    const fragment = document.createDocumentFragment();
    for (const item of filtered.slice(page * pageSize, (page + 1) * pageSize)) {
      const row = el('tr');
      const address = el('td');
      const href = safeLink(item.url);
      address.append(href ? el('a', item.url, { href }) : el('span', item.url || 'Missing address'));
      row.append(address, el('td', item.modified || 'Not provided', { class: 'modified' }));
      fragment.append(row);
    }
    tbody.replaceChildren(fragment);
    const unit = isIndex ? 'sitemaps' : 'pages';
    count.textContent = `${filtered.length.toLocaleString()} of ${entries.length.toLocaleString()} ${unit}`;
    empty.hidden = filtered.length !== 0;
    empty.textContent = entries.length ? 'No addresses match your search.' : 'This sitemap has no entries.';
    tableWrap.hidden = filtered.length === 0;
    nav.hidden = filtered.length <= pageSize;
    pageLabel.textContent = `Page ${page + 1} of ${totalPages}`;
    previous.disabled = page === 0;
    next.disabled = page >= totalPages - 1;
  }
  input.addEventListener('input', () => {
    const query = input.value.trim().toLowerCase();
    filtered = query ? entries.filter(item => item.url.toLowerCase().includes(query)) : entries;
    page = 0;
    render();
  });
  previous.addEventListener('click', () => { page--; render(); });
  next.addEventListener('click', () => { page++; render(); });
  toggle.addEventListener('click', () => {
    const showRaw = raw.hidden;
    raw.hidden = !showRaw;
    viewer.hidden = showRaw;
    toggle.textContent = showRaw ? 'Show table' : 'Show XML';
    toggle.setAttribute('aria-expanded', String(showRaw));
  });
  render();
})();
