(() => {
  'use strict';
  // Detect the document itself, not its filename: sitemap URLs need not end in .xml.
  if (!['application/xml', 'text/xml'].includes(document.contentType)) return;
  const NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';
  const IMAGE_NS = 'http://www.google.com/schemas/sitemap-image/1.1';
  const VIDEO_NS = 'http://www.google.com/schemas/sitemap-video/1.1';
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const original = document.documentElement;
  // Chromium may already have placed the XML inside its built-in tree viewer.
  const source = original?.namespaceURI === NS ? original
    : document.getElementById('webkit-xml-viewer-source-xml')?.firstElementChild;
  if (!source || source.namespaceURI !== NS || !['urlset', 'sitemapindex'].includes(source.localName)) return;
  if (document.getElementsByTagName('parsererror').length) return;

  const isIndex = source.localName === 'sitemapindex';
  const itemName = isIndex ? 'sitemap' : 'url';
  const field = (element, name, namespace = NS) => Array.from(element.children)
    .find(child => child.namespaceURI === namespace && child.localName === name)?.textContent.trim() || '';
  const pages = Array.from(source.children)
    .filter(child => child.namespaceURI === NS && child.localName === itemName);
  const isVideo = !isIndex && pages.some(item => Array.from(item.children)
    .some(child => child.namespaceURI === VIDEO_NS && child.localName === 'video'));
  const entries = pages.flatMap(item => {
    const modified = field(item, 'lastmod');
    const imageCount = !isIndex ? Array.from(item.children)
      .filter(child => child.namespaceURI === IMAGE_NS && child.localName === 'image').length : 0;
    const base = { url: field(item, 'loc'), modified, timestamp: Date.parse(modified), imageCount };
    const videos = isVideo ? Array.from(item.children)
      .filter(child => child.namespaceURI === VIDEO_NS && child.localName === 'video') : [];
    if (!videos.length) return [{ ...base, title: '', description: '', tags: '', duration: NaN, published: '', publishedTimestamp: NaN }];
    return videos.map(video => {
      const value = name => field(video, name, VIDEO_NS);
      const duration = value('duration');
      const published = value('publication_date');
      return { ...base, video: true, title: value('title'), description: value('description'),
        thumbnail: value('thumbnail_loc'), player: value('player_loc'), content: value('content_loc'),
        tags: Array.from(video.children).filter(child => child.namespaceURI === VIDEO_NS && child.localName === 'tag')
          .map(tag => tag.textContent.trim()).filter(Boolean).join(', '),
        duration: /^\d+$/.test(duration) && Number.isSafeInteger(Number(duration)) ? Number(duration) : NaN,
        published, publishedTimestamp: Date.parse(published) };
    });
  });
  const hasImages = !isIndex && !isVideo && entries.some(item => item.imageCount > 0);
  const videoCount = entries.filter(item => item.video).length;
  const heading = isIndex ? 'Sitemap index' : isVideo ? 'XML video sitemap' : 'XML sitemap';
  const xml = new XMLSerializer().serializeToString(source);
  const safeLink = value => {
    try {
      const url = new URL(value);
      return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  };
  const el = (name, text, attrs = {}) => {
    const node = document.createElementNS(XHTML, name);
    if (text !== undefined) node.textContent = text;
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
    return node;
  };

  const html = el('html', undefined, { id: 'pretty-sitemap', lang: 'en', class: isVideo ? 'video-sitemap' : hasImages ? 'image-sitemap' : '' });
  const head = el('head');
  head.append(el('meta', undefined, { name: 'viewport', content: 'width=device-width, initial-scale=1' }),
    el('title', `${heading} · ${location.hostname || 'Local file'}`));
  const body = el('body');
  const main = el('main');
  const header = el('header');
  header.append(el('p', 'PRETTY XML SITEMAPS', { class: 'eyebrow' }),
    el('h1', heading),
    el('p', location.href, { class: 'source' }),
    el('p', isIndex ? 'Browse the sitemaps that list this site’s pages.' : isVideo ? 'Browse the videos listed in this sitemap. Click a thumbnail to open the video, or a title to visit its page.' : 'Browse the pages listed in this sitemap.', { class: 'intro' }));
  const toggle = el('button', 'Show XML', { type: 'button', 'aria-expanded': 'false', 'aria-controls': 'xml-data' });
  header.append(toggle);
  const viewer = el('section', undefined, { 'aria-label': 'Sitemap entries' });
  const toolbar = el('div', undefined, { class: 'toolbar' });
  const label = el('label', isVideo ? 'Filter videos' : 'Filter by address', { for: 'filter' });
  const input = el('input', undefined, { id: 'filter', type: 'search', placeholder: isVideo ? 'Search titles, descriptions, tags or addresses…' : 'Type part of an address…', autocomplete: 'off' });
  const count = el('p', undefined, { role: 'status', 'aria-live': 'polite', class: 'count' });
  toolbar.append(label, input, count);
  const tableWrap = el('div', undefined, { class: 'table-wrap', ...(isVideo ? { tabindex: '0', role: 'region', 'aria-label': 'Video table, scroll horizontally for more columns' } : {}) });
  const table = el('table');
  const caption = el('caption', isIndex ? 'Sitemaps and their last modification dates' : isVideo ? 'Video thumbnails, titles, descriptions, tags, durations and publication dates' : hasImages ? 'Page addresses, image counts and last modification dates' : 'Page addresses and their last modification dates', { class: 'sr-only' });
  const thead = el('thead');
  const headings = el('tr');
  if (isVideo) headings.append(el('th', 'Video', { scope: 'col', class: 'thumbnail-heading' }));
  const columns = (isVideo ? [
    { key: 'title', label: 'Title' }, { key: 'description', label: 'Description' },
    { key: 'tags', label: 'Tags' }, { key: 'duration', label: 'Duration', numeric: 'duration' },
    { key: 'published', label: 'Publication date', numeric: 'publishedTimestamp', descendingFirst: true }
  ] : [
    { key: 'url', label: isIndex ? 'Sitemap' : 'Page address' },
    ...(hasImages ? [{ key: 'imageCount', label: 'Images', numeric: 'imageCount', descendingFirst: true }] : []),
    { key: 'modified', label: 'Last modified', numeric: 'timestamp', descendingFirst: true }
  ]).map(column => {
    const th = el('th', undefined, { scope: 'col' });
    const button = el('button', column.label, { type: 'button', class: 'sort-button' });
    const arrow = el('span', '↕', { 'aria-hidden': 'true', class: 'sort-arrow' });
    button.append(arrow);
    th.append(button);
    headings.append(th);
    return { ...column, th, button, arrow };
  });
  thead.append(headings);
  const tbody = el('tbody');
  table.append(caption, thead, tbody);
  tableWrap.append(table);
  const empty = el('p', '', { class: 'empty', hidden: '' });
  const nav = el('nav', undefined, { 'aria-label': 'Table pages', class: 'pagination' });
  const previous = el('button', 'Previous', { type: 'button' });
  const pageLabel = el('span');
  const next = el('button', 'Next', { type: 'button' });
  nav.append(previous, pageLabel, next);
  viewer.append(toolbar, tableWrap, empty, nav);
  const raw = el('pre', xml, { id: 'xml-data', hidden: '', tabindex: '0', 'aria-label': 'Sitemap XML data' });
  main.append(header, viewer, raw, el('footer', 'Displayed by Pretty XML Sitemaps. The file on the website is unchanged.'));
  body.append(main);
  html.append(head, body);
  // Drop processing instructions too, so the replacement cannot trigger an XSL transform.
  while (document.firstChild) document.removeChild(document.firstChild);
  document.appendChild(html);

  let filtered = entries;
  let page = 0;
  let sortKey = null;
  let sortDirection = 'ascending';
  const collator = new Intl.Collator('en', { numeric: true, sensitivity: 'base' });
  function updateOrder() {
    const query = input.value.trim().toLowerCase();
    filtered = entries.filter(item => !query || [item.url, ...(isVideo ? [item.title, item.description, item.tags] : [])]
      .some(value => value.toLowerCase().includes(query)));
    if (sortKey) {
      const direction = sortDirection === 'ascending' ? 1 : -1;
      const column = columns.find(column => column.key === sortKey);
      filtered.sort((a, b) => {
        if (!column.numeric) return direction * collator.compare(a[sortKey], b[sortKey]);
        // Missing or unparseable dates remain last in either direction.
        const aValid = Number.isFinite(a[column.numeric]);
        const bValid = Number.isFinite(b[column.numeric]);
        if (aValid !== bValid) return aValid ? -1 : 1;
        return aValid ? direction * (a[column.numeric] - b[column.numeric]) : 0;
      });
    }
    page = 0;
    render();
  }
  const pageSize = 100;
  function render() {
    for (const column of columns) {
      const active = sortKey === column.key;
      if (active) column.th.setAttribute('aria-sort', sortDirection);
      else column.th.removeAttribute('aria-sort');
      column.arrow.textContent = active ? (sortDirection === 'ascending' ? '↑' : '↓') : '↕';
      const nextDirection = active ? (sortDirection === 'ascending' ? 'descending' : 'ascending')
        : (column.descendingFirst ? 'descending' : 'ascending');
      column.button.title = `Sort ${column.label.toLowerCase()} ${nextDirection}`;
    }
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, totalPages - 1);
    const fragment = document.createDocumentFragment();
    for (const item of filtered.slice(page * pageSize, (page + 1) * pageSize)) {
      const row = el('tr');
      if (isVideo) {
        const thumbnail = el('td', undefined, { class: 'thumbnail-cell' });
        const destination = safeLink(item.player) || safeLink(item.content);
        const imageUrl = safeLink(item.thumbnail);
        const fallback = el('span', item.video ? 'No thumbnail' : 'No video', { class: 'thumbnail-fallback' });
        const preview = destination ? el('a', undefined, { href: destination, 'aria-label': `Open video: ${item.title || item.url}`, rel: 'noreferrer' }) : el('span');
        if (imageUrl) {
          const image = el('img', undefined, { src: imageUrl, alt: item.title ? `Thumbnail: ${item.title}` : 'Video thumbnail',
            width: '160', height: '90', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
          image.addEventListener('error', () => image.replaceWith(fallback), { once: true });
          preview.append(image);
        } else preview.append(fallback);
        thumbnail.append(preview);
        const title = el('td', undefined, { class: 'video-title' });
        const href = safeLink(item.url);
        const name = item.title || item.url || 'Missing title';
        title.append(href ? el('a', name, { href }) : el('span', name));
        if (item.title && item.url) title.append(el('span', item.url, { class: 'video-address' }));
        const description = el('td', undefined, { class: 'video-description' });
        if (item.description.length > 200) {
          const details = el('details');
          details.append(el('summary', item.description.slice(0, 200) + '…'), el('p', item.description));
          description.append(details);
        } else description.textContent = item.description || 'Not provided';
        const duration = Number.isFinite(item.duration)
          ? `${Math.floor(item.duration / 60)}:${String(item.duration % 60).padStart(2, '0')}` : 'Not provided';
        const published = el('td', undefined, { class: 'modified' });
        published.append(Number.isFinite(item.publishedTimestamp)
          ? el('time', item.published.replace('T', ' ').slice(0, 16), { datetime: item.published, title: item.published })
          : el('span', item.published || 'Not provided'));
        row.append(thumbnail, title, description, el('td', item.tags || 'Not provided'), el('td', duration), published);
      } else {
        const address = el('td');
        const href = safeLink(item.url);
        address.append(href ? el('a', item.url, { href }) : el('span', item.url || 'Missing address'));
        row.append(address);
        if (hasImages) row.append(el('td', item.imageCount.toLocaleString(), { class: 'image-count' }));
        row.append(el('td', item.modified || 'Not provided', { class: 'modified' }));
      }
      fragment.append(row);
    }
    tbody.replaceChildren(fragment);
    const unit = isIndex ? 'sitemaps' : isVideo ? (videoCount === entries.length ? 'videos' : 'entries') : 'pages';
    count.textContent = `${filtered.length.toLocaleString()} of ${entries.length.toLocaleString()} ${unit}${isVideo ? ` across ${pages.length.toLocaleString()} pages` : ''}`;
    empty.hidden = filtered.length !== 0;
    empty.textContent = entries.length ? (isVideo ? 'No videos match your search.' : 'No addresses match your search.') : 'This sitemap has no entries.';
    tableWrap.hidden = filtered.length === 0;
    nav.hidden = filtered.length <= pageSize;
    pageLabel.textContent = `Page ${page + 1} of ${totalPages}`;
    previous.disabled = page === 0;
    next.disabled = page >= totalPages - 1;
  }
  input.addEventListener('input', updateOrder);
  for (const column of columns) {
    column.button.addEventListener('click', () => {
      sortDirection = sortKey === column.key ? (sortDirection === 'ascending' ? 'descending' : 'ascending')
        : (column.descendingFirst ? 'descending' : 'ascending');
      sortKey = column.key;
      updateOrder();
    });
  }
  previous.addEventListener('click', () => { page--; render(); });
  next.addEventListener('click', () => { page++; render(); });
  toggle.addEventListener('click', () => {
    const showRaw = raw.hidden;
    raw.hidden = !showRaw;
    viewer.hidden = showRaw;
    toggle.textContent = showRaw ? 'Show table' : 'Show XML';
    toggle.setAttribute('aria-expanded', String(showRaw));
  });
  render();
})();
