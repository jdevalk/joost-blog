(() => {
  'use strict';
  const requestedSource = globalThis.__prettySitemapRequestedSource;
  const requestedBytes = globalThis.__prettySitemapRequestedBytes;
  const requestedContentType = globalThis.__prettySitemapRequestedContentType;
  const quality = globalThis.__prettySitemapQuality;
  const live = globalThis.__prettySitemapLive;
  delete globalThis.__prettySitemapRequestedSource;
  delete globalThis.__prettySitemapRequestedBytes;
  delete globalThis.__prettySitemapRequestedContentType;
  if (globalThis.__prettySitemapRendered && document.documentElement.id === 'pretty-sitemap') return;
  // Detect the document itself, not its filename: sitemap URLs need not end in .xml.
  const contentType = document.contentType.toLowerCase();
  if (!requestedSource && !['application/xml', 'text/xml', 'text/plain'].includes(contentType) && !/^[^/]+\/[^;\s]+\+xml$/.test(contentType)) return;
  const NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';
  const IMAGE_NS = 'http://www.google.com/schemas/sitemap-image/1.1';
  const VIDEO_NS = 'http://www.google.com/schemas/sitemap-video/1.1';
  const NEWS_NS = 'http://www.google.com/schemas/sitemap-news/0.9';
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const original = document.documentElement;
  // Chromium may already have placed the XML inside its built-in tree viewer.
  let source = requestedSource || (original?.namespaceURI === NS ? original
    : document.getElementById('webkit-xml-viewer-source-xml')?.firstElementChild);
  // Chrome displays application/rss+xml as text/plain. Read its existing text
  // without refetching; only a valid sitemap root/namespace may replace the page.
  if (!source && contentType === 'text/plain') {
    const text = document.body?.querySelector('pre')?.textContent;
    if (text && /^\s*</.test(text)) source = new DOMParser().parseFromString(text, 'application/xml').documentElement;
  }
  if (!source || source.namespaceURI !== NS || !['urlset', 'sitemapindex'].includes(source.localName)) return;
  if (source.ownerDocument.getElementsByTagName('parsererror').length) return;

  // Chrome may normalize feed MIME types to text/plain. Do not claim that the
  // document type is the original response header, or refetch just to read it.
  const sitemapContentType = (requestedSource ? requestedContentType : contentType)?.split(';')[0].trim().toLowerCase();
  const hasMimeWarning = Boolean(sitemapContentType && !['application/xml', 'text/xml'].includes(sitemapContentType));
  const isIndex = source.localName === 'sitemapindex';
  const itemName = isIndex ? 'sitemap' : 'url';
  const field = (element, name, namespace = NS) => Array.from(element.children)
    .find(child => child.namespaceURI === namespace && child.localName === name)?.textContent.trim() || '';
  const pages = Array.from(source.children)
    .filter(child => child.namespaceURI === NS && child.localName === itemName);
  const report = quality.analyze(pages.map(item => ({
    url: field(item, 'loc'), modified: field(item, 'lastmod'),
    ignoredFields: isIndex ? [] : Array.from(item.children).filter(child => child.namespaceURI === NS && ['priority', 'changefreq'].includes(child.localName)).map(child => child.localName),
    newsCount: isIndex ? 0 : Array.from(item.children).filter(child => child.namespaceURI === NEWS_NS && child.localName === 'news').length,
    dates: Array.from(item.children).flatMap(child => {
      if (child.namespaceURI === NEWS_NS && child.localName === 'news')
        return [{ field: 'News publication date', value: field(child, 'publication_date', NEWS_NS) }];
      if (child.namespaceURI === VIDEO_NS && child.localName === 'video')
        return [{ field: 'Video publication date', value: field(child, 'publication_date', VIDEO_NS) }];
      return [];
    })
  })));
  const isVideo = !isIndex && pages.some(item => Array.from(item.children)
    .some(child => child.namespaceURI === VIDEO_NS && child.localName === 'video'));
  const isNews = !isIndex && pages.some(item => Array.from(item.children)
    .some(child => child.namespaceURI === NEWS_NS && child.localName === 'news'));
  const entries = pages.flatMap((item, index) => {
    const modified = field(item, 'lastmod');
    const imageCount = !isIndex ? Array.from(item.children)
      .filter(child => child.namespaceURI === IMAGE_NS && child.localName === 'image').length : 0;
    const alternates = !isIndex ? Array.from(item.children)
      .filter(child => child.namespaceURI === XHTML && child.localName === 'link' && child.hasAttribute('hreflang') &&
        (child.getAttribute('rel') || '').toLowerCase().split(/\s+/).includes('alternate'))
      .map(child => ({ language: (child.getAttribute('hreflang') || '').trim(), href: (child.getAttribute('href') || '').trim() })) : [];
    const news = Array.from(item.children).find(child => child.namespaceURI === NEWS_NS && child.localName === 'news');
    const publication = news && Array.from(news.children).find(child => child.namespaceURI === NEWS_NS && child.localName === 'publication');
    const newsPublished = news ? field(news, 'publication_date', NEWS_NS) : '';
    const feedback = report.items[index];
    const liveURL = feedback.address.fetchable ? live.normalized(feedback.address.fetchable) : null;
    const base = { sourceIndex: index, url: field(item, 'loc'), modified, feedback, liveURL, timestamp: feedback.kind === 'invalid' ? NaN : Date.parse(modified), imageCount,
      alternates, languages: alternates.map(alternate => alternate.language).join(', '),
      news: Boolean(news), newsTitle: news ? field(news, 'title', NEWS_NS) : '',
      publication: publication ? field(publication, 'name', NEWS_NS) : '',
      language: publication ? field(publication, 'language', NEWS_NS) : '',
      newsPublished, newsTimestamp: quality.dateKind(newsPublished) === 'invalid' ? NaN : Date.parse(newsPublished) };
    const videos = isVideo ? Array.from(item.children)
      .filter(child => child.namespaceURI === VIDEO_NS && child.localName === 'video') : [];
    if (!videos.length) return [{ ...base, title: '', description: '', tags: '', duration: NaN, published: '', publishedTimestamp: NaN }];
    return videos.map(video => {
      const value = name => field(video, name, VIDEO_NS);
      const duration = value('duration');
      const published = value('publication_date');
      return { ...base, video: true, title: value('title'), description: value('description'),
        thumbnail: value('thumbnail_loc'), player: value('player_loc'), content: value('content_loc'),
        tags: Array.from(video.children).filter(child => child.namespaceURI === VIDEO_NS && child.localName === 'tag')
          .map(tag => tag.textContent.trim()).filter(Boolean).join(', '),
        duration: /^\d+$/.test(duration) && Number.isSafeInteger(Number(duration)) ? Number(duration) : NaN,
        published, publishedTimestamp: quality.dateKind(published) === 'invalid' ? NaN : Date.parse(published) };
    });
  });
  const hasImages = !isIndex && !isVideo && entries.some(item => item.imageCount > 0);
  const hasAlternates = entries.some(item => item.alternates.length > 0);
  const videoCount = entries.filter(item => item.video).length;
  const heading = isIndex ? 'Sitemap Index' : isVideo ? (isNews ? 'XML Video & News Sitemap' : 'XML Video Sitemap') : isNews ? 'XML News Sitemap' : 'XML Sitemap';
  const xml = new XMLSerializer().serializeToString(source);
  const safeLink = value => {
    try {
      const url = new URL(value);
      return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  };
  const el = (name, text, attrs = {}) => {
    const node = document.createElementNS(XHTML, name);
    if (text !== undefined) node.textContent = text;
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
    return node;
  };

  const html = el('html', undefined, { id: 'pretty-sitemap', lang: 'en', class: [isVideo && 'video-sitemap', isNews && 'news-sitemap', hasImages && 'image-sitemap', hasAlternates && 'language-sitemap'].filter(Boolean).join(' ') });
  const logoURL = chrome.runtime.getURL('icons/sitemap-inspector.svg');
  const head = el('head');
  head.append(el('meta', undefined, { name: 'viewport', content: 'width=device-width, initial-scale=1' }),
    el('title', `Sitemap Inspector · ${heading} · ${location.hostname || 'Local file'}`),
    el('link', undefined, { rel: 'icon', type: 'image/svg+xml', sizes: 'any', href: logoURL }));
  const body = el('body');
  const main = el('main');
  const header = el('header');
  const title = el('h1');
  title.textContent = heading;
  const branding = el('div', undefined, { class: 'sitemap-brand' });
  branding.append(el('img', undefined, { class: 'sitemap-logo', src: logoURL, alt: 'Sitemap Inspector', width: '64', height: '64' }), title);
  header.append(branding);
  const toggle = el('button', 'Show XML', { type: 'button', class: 'view-toggle', 'aria-expanded': 'false', 'aria-controls': 'xml-data' });
  header.append(toggle);
  const viewer = el('section', undefined, { 'aria-label': 'Sitemap entries' });
  const warningFilter = el('select', undefined, { id: 'warning-filter' });
  warningFilter.append(el('option', 'All entries', { value: '' }));
  const feedback = el('section', undefined, { class: 'sitemap-feedback', 'aria-labelledby': 'feedback-heading' });
  feedback.append(el('h2', 'Sitemap feedback', { id: 'feedback-heading' }));
  const findings = el('ul');
  const sizeFinding = el('li', '', { hidden: '' });
  findings.append(sizeFinding);
  if (hasMimeWarning) {
    const finding = el('li', undefined, { class: 'mime-warning' });
    finding.append(el('strong', 'Warning: unexpected MIME type. '),
      document.createTextNode(`${requestedSource ? 'The response Content-Type is' : 'The browser reports'} ${sitemapContentType}. Serve this sitemap with Content-Type: application/xml or text/xml.${!requestedSource && sitemapContentType === 'text/plain' ? ' Chrome may report RSS or Atom responses as text/plain.' : ''}`));
    findings.append(finding);
  }
  let nestedIndex = false;
  const nestedFinding = el('li', undefined, { class: 'feedback-error nested-index-error', hidden: '' });
  findings.append(nestedFinding);
  const hasErrors = report.tooManyEntries || report.tooManyNews || Boolean(report.counts['invalid-date'] || report.counts['invalid-url']);
  if (report.tooManyEntries) {
    const finding = el('li', undefined, { class: 'feedback-error' });
    finding.append(el('strong', `Error: too many entries (${pages.length.toLocaleString()}). `),
      document.createTextNode(`The limit is ${quality.MAX_ENTRIES.toLocaleString()} ${isIndex ? 'sitemaps per index' : 'URLs per sitemap'}. Split this file into smaller files.`));
    findings.append(finding);
  }
  if (report.tooManyNews) {
    const finding = el('li', undefined, { class: 'feedback-error' });
    finding.append(el('strong', `Error: too many news entries (${report.newsCount.toLocaleString()}). `),
      document.createTextNode(`The limit is ${quality.MAX_NEWS.toLocaleString()} news entries per sitemap. Split this file into smaller files.`));
    findings.append(finding);
  }
  const affected = count => `${count.toLocaleString()} of ${pages.length.toLocaleString()} ${isIndex ? (pages.length === 1 ? 'sitemap' : 'sitemaps') : (pages.length === 1 ? 'page' : 'pages')}`;
  const subject = isIndex ? 'sitemap file' : 'page';
  for (const [kind, name, advice] of [
    ['invalid-url', 'Invalid URL', 'Each entry needs an absolute HTTP or HTTPS loc address, shorter than 2,048 characters and without malformed or unescaped characters.'],
    ['duplicate-url', 'Duplicate URL', 'Remove repeated entries for the same address.'],
    ['conflicting-lastmod', 'Conflicting last modified', 'The same address has different lastmod values. Keep one entry with the actual modification date.'],
    ['suspicious-url', 'Suspicious URL', 'Review fragments, tracking parameters, and embedded credentials. Use the clean canonical address.'],
    ['future-lastmod', 'Future last modified', 'Modification dates are ahead of the current time. Allows five minutes for clock differences, or one day for dates without a timezone.'],
    ['ignored-fields', 'Fields ignored by Google and Bing', 'Google and Bing ignore priority and changefreq. These optional fields can be removed.'],
    ['invalid-date', 'Invalid date format', 'Use a real calendar date (YYYY-MM-DD) or a timestamp with T and a timezone, such as 2026-09-22T09:30:00Z. Checks include lastmod and news/video publication dates.'],
    ['missing', 'Missing last modified', `Add lastmod when the ${subject}’s actual modification date is known.`],
    ['date-only', 'Date only, no time', 'Include the time and timezone when known to distinguish changes within a day.'],
    ['mixed-protocols', 'Mixed HTTP and HTTPS', `${report.protocols['http:'].toLocaleString()} HTTP and ${report.protocols['https:'].toLocaleString()} HTTPS addresses. Use the canonical protocol consistently in loc values.`],
    ['repeated-lastmod', 'Repeated last modified', `${report.repeatedGroups.toLocaleString()} lastmod ${report.repeatedGroups === 1 ? 'value is shared' : 'values are each shared'} by more than 10 distinct URLs. Confirm these reflect actual changes, rather than the sitemap generation time.`]
  ]) {
    if (!report.counts[kind]) continue;
    const error = ['invalid-date', 'invalid-url'].includes(kind);
    const informational = kind === 'ignored-fields';
    const finding = el('li', undefined, { class: error ? 'feedback-error' : informational ? 'feedback-info' : '' });
    const allAffected = report.counts[kind] === pages.length;
    const allEntries = pages.length === 1 ? `The ${isIndex ? 'sitemap' : 'page'}` : `All ${isIndex ? 'sitemaps' : 'pages'}`;
    let summary = `${name}: ${affected(report.counts[kind])}.`;
    let detail = advice;
    if (allAffected && kind === 'ignored-fields') summary = `${allEntries} ${pages.length === 1 ? 'includes' : 'include'} fields ignored by Google and Bing.`;
    if (allAffected && kind === 'date-only') summary = `${allEntries} ${pages.length === 1 ? 'has' : 'have'} a last modified date without a time.`;
    if (allAffected && kind === 'repeated-lastmod') {
      summary = report.repeatedGroups === 1
        ? `${allEntries} share the same last modified value.`
        : `${allEntries} have repeated last modified values.`;
      if (report.repeatedGroups === 1) detail = 'Confirm this reflects actual changes, rather than the sitemap generation time.';
    }
    finding.append(el('strong', `${error ? 'Error' : informational ? 'Info' : 'Warning'}: ${summary}`), document.createTextNode(` ${detail}`));
    findings.append(finding);
    warningFilter.append(el('option', `${name} (${report.counts[kind].toLocaleString()})`, { value: kind }));
  }
  let hasLiveErrors = false, hasLiveFindings = false;
  const liveFindings = [...(isIndex ? [
    ['child-entry-limit', 'Child sitemaps over the entry limit', result => result?.sitemap?.entries > quality.MAX_ENTRIES, 'Each child file can contain at most 50,000 entries. Split affected files into smaller sitemaps.'],
    ['child-size-limit', 'Child sitemaps over the size limit', result => Boolean(result?.sitemap?.overSize), 'Each child file can be at most 50 MB (52,428,800 bytes) uncompressed. Split affected files into smaller sitemaps.'],
    ['child-nested-index', 'Nested sitemap indexes', result => result?.sitemap?.kind === 'sitemapindex', 'List individual sitemap files in this index, or submit child indexes separately.']
  ] : []).map(item => [...item, 'Error']),
    ['robots-blocked', 'URLs blocked for Googlebot', result => result?.robots?.state === 'blocked', 'These URLs match a Disallow rule in the fetched robots.txt. Crawl blocking does not guarantee removal from search results.', 'Warning'],
    ['robots-unavailable', 'Googlebot robots.txt could not be verified', result => result?.robots?.state === 'unknown', 'The robots.txt response could not be checked. These URLs are not assumed to be allowed.', 'Info']
  ].map(([kind, name, matches, advice, severity]) => {
    const finding = el('li', undefined, { class: severity === 'Error' ? 'feedback-error' : severity === 'Info' ? 'feedback-info' : '', 'data-live-finding': kind, hidden: '' });
    findings.append(finding);
    return { kind, name, matches, advice, severity, finding, option: null };
  });
  feedback.append(findings, el('p', 'Missing and date-only lastmod values are allowed by the sitemap protocol. Repeated dates can be legitimate. These checks do not validate the whole sitemap.', { class: 'feedback-note' }));
  {
    const controls = el('div', undefined, { class: 'feedback-filter' });
    controls.append(el('label', 'Show entries', { for: 'warning-filter' }), warningFilter);
    feedback.append(controls);
  }
  viewer.append(feedback);
  const liveOverview = el('div', undefined, { class: 'live-overview' });
  const liveControls = el('section', undefined, { class: 'live-checks', 'aria-labelledby': 'live-heading' });
  liveControls.append(el('h2', 'Live URL checks', { id: 'live-heading' }),
    el('p', `${isIndex ? 'Check child sitemaps for redirects, HTTP errors, nested indexes, entry counts, and uncompressed size, including .xml.gz files.' : 'Check filtered URLs for redirects, HTTP errors, noindex, and canonical mismatches.'} Also checks each URL against Googlebot rules in its own site’s robots.txt. Each click checks up to 100 distinct URLs without cookies.${isIndex ? ' Each sitemap is read up to the 50 MB limit, with a 30-second timeout.' : ''} Other sites may block access. Results use the robots.txt returned to this browser, which may differ from Google’s cached copy; they do not show Google’s indexing status.`));
  const liveStart = el('button', 'Check URLs', { type: 'button' });
  const liveStop = el('button', 'Stop checks', { type: 'button', hidden: '' });
  const liveStatus = el('p', 'No URLs checked. No requests are sent until you start.', { role: 'status', 'aria-live': 'polite' });
  const liveFilter = el('select', undefined, { id: 'live-filter' });
  for (const [value, label] of [['', 'All results'], ['findings', 'With findings'], ['incomplete', 'Could not fully check'], ['unchecked', 'Not checked']]) liveFilter.append(el('option', label, { value }));
  const liveActions = el('div', undefined, { class: 'live-actions' });
  liveActions.append(liveStart, liveStop, el('label', 'Live results', { for: 'live-filter' }), liveFilter);
  liveControls.append(liveActions, liveStatus);
  const stats = el('aside', undefined, { class: 'sitemap-statistics', 'aria-labelledby': 'statistics-heading' });
  stats.append(el('h2', 'Statistics', { id: 'statistics-heading' }));
  const statsList = el('dl');
  const entriesStat = el('dd', pages.length.toLocaleString(), { id: 'statistics-entries' });
  const sizeStat = el('dd', 'Not available', { id: 'statistics-size' });
  const statRow = (label, value) => { const row = el('div'); row.append(el('dt', label), value); return row; };
  statsList.append(statRow(isIndex ? 'Sitemaps' : 'URLs', entriesStat), statRow('Uncompressed size', sizeStat));
  stats.append(statsList, el('p', 'Totals for this file, before filtering.'));
  liveOverview.append(liveControls, stats);
  viewer.append(liveOverview);
  const formatBytes = bytes => bytes < 1024 ? `${bytes.toLocaleString()} B`
    : bytes < 1048576 ? `${(bytes / 1024).toLocaleString(undefined, { maximumFractionDigits: 1 })} KB`
      : `${(bytes / 1048576).toLocaleString(undefined, { maximumFractionDigits: 2 })} MB`;
  function updateSize(bytes) {
    const issue = quality.sizeIssue(bytes);
    sizeStat.textContent = issue === 'unknown' ? 'Not available' : formatBytes(bytes);
    sizeStat.title = issue === 'unknown' ? 'The browser did not expose the original response size.' : `${bytes.toLocaleString()} bytes uncompressed`;
    sizeStat.classList.toggle('feedback-error', issue === 'too-large');
    entriesStat.classList.toggle('feedback-error', report.tooManyEntries);
    sizeFinding.hidden = !issue;
    sizeFinding.className = issue === 'too-large' ? 'feedback-error' : '';
    sizeFinding.replaceChildren();
    if (issue === 'too-large') {
      sizeFinding.append(el('strong', `Error: sitemap too large (${bytes.toLocaleString()} bytes). `),
        document.createTextNode(`The limit is 50 MB (${quality.MAX_BYTES.toLocaleString()} bytes) uncompressed. Split this file into smaller files.`));
    } else if (issue === 'unknown') {
      sizeFinding.textContent = 'File size not verified: the browser did not expose the original response size. The limit is 50 MB (52,428,800 bytes) uncompressed.';
    }
    feedback.classList.toggle('has-errors', hasErrors || nestedIndex || hasLiveErrors || issue === 'too-large');
    feedback.hidden = !hasErrors && !nestedIndex && !hasLiveFindings && !hasMimeWarning && !Object.keys(report.counts).length && !issue;
  }
  // Navigation timing measures the actual decoded response, not reserialized XML
  // or the compressed Content-Length. It may only become available after load.
  const navigationBytes = () => performance.getEntriesByType('navigation')[0]?.decodedBodySize;
  updateSize(requestedSource ? requestedBytes : navigationBytes());
  if (!requestedSource && !navigationBytes()) {
    const observer = new PerformanceObserver(list => {
      const navigation = list.getEntries().find(entry => entry.entryType === 'navigation');
      if (navigation) { updateSize(navigation.decodedBodySize); observer.disconnect(); }
    });
    observer.observe({ type: 'navigation', buffered: true });
  }
  const toolbar = el('div', undefined, { class: 'toolbar' });
  const label = el('label', isVideo ? 'Filter videos' : isNews ? 'Filter news' : 'Filter by address', { for: 'filter' });
  const input = el('input', undefined, { id: 'filter', type: 'search', placeholder: isVideo ? 'Search titles, descriptions, tags or addresses…' : isNews ? 'Search titles, publications, languages or addresses…' : hasAlternates ? 'Search addresses or languages…' : 'Type part of an address…', autocomplete: 'off' });
  const count = el('p', undefined, { role: 'status', 'aria-live': 'polite', class: 'count' });
  toolbar.append(label, input, count);
  const tableWrap = el('div', undefined, { class: 'table-wrap', ...((isVideo || isNews || hasAlternates) ? { tabindex: '0', role: 'region', 'aria-label': `${isVideo ? 'Video' : isNews ? 'News' : 'Sitemap'} table, scroll horizontally for more columns` } : {}) });
  const table = el('table');
  const caption = el('caption', isIndex ? 'Sitemaps and their last modification dates' : isVideo ? 'Video thumbnails, titles, descriptions, tags, durations and publication dates' : isNews ? 'News titles, publications, languages, publication dates and modification dates' : hasImages ? 'Page addresses, image counts and last modification dates' : 'Page addresses and their last modification dates', { class: 'sr-only' });
  const thead = el('thead');
  const headings = el('tr');
  if (isVideo) headings.append(el('th', 'Video', { scope: 'col', class: 'thumbnail-heading' }));
  const newsColumns = [
    { key: 'newsTitle', label: isVideo ? 'News title' : 'Title' },
    { key: 'publication', label: 'Publication' }, { key: 'language', label: 'Language' },
    { key: 'newsPublished', label: isVideo ? 'News publication date' : 'Publication date', numeric: 'newsTimestamp', descendingFirst: true }
  ];
  const columns = (isVideo ? [
    { key: 'title', label: 'Title' }, { key: 'description', label: 'Description' },
    { key: 'tags', label: 'Tags' }, { key: 'duration', label: 'Duration', numeric: 'duration' },
    { key: 'published', label: 'Publication date', numeric: 'publishedTimestamp', descendingFirst: true },
    ...(isNews ? newsColumns : [])
  ] : [
    ...(isNews ? newsColumns : [{ key: 'url', label: isIndex ? 'Sitemap' : 'Page address' }]),
    ...(hasImages ? [{ key: 'imageCount', label: 'Images', numeric: 'imageCount', descendingFirst: true }] : []),
    { key: 'modified', label: 'Last modified', numeric: 'timestamp', descendingFirst: true }
  ]).concat(hasAlternates ? [{ key: 'languages', label: 'Languages' }] : []).map(column => {
    const th = el('th', undefined, { scope: 'col' });
    const button = el('button', column.label, { type: 'button', class: 'sort-button' });
    const arrow = el('span', '↕', { 'aria-hidden': 'true', class: 'sort-arrow' });
    button.append(arrow);
    th.append(button);
    headings.append(th);
    return { ...column, th, button, arrow };
  });
  thead.append(headings);
  const tbody = el('tbody');
  table.append(caption, thead, tbody);
  tableWrap.append(table);
  const empty = el('p', '', { class: 'empty', hidden: '' });
  const nav = el('nav', undefined, { 'aria-label': 'Table pages', class: 'pagination' });
  const previous = el('button', 'Previous', { type: 'button' });
  const pageLabel = el('span');
  const next = el('button', 'Next', { type: 'button' });
  nav.append(previous, pageLabel, next);
  viewer.append(toolbar, tableWrap, empty, nav);
  const raw = el('pre', xml, { id: 'xml-data', hidden: '', tabindex: '0', 'aria-label': 'Sitemap XML data' });
  main.append(header, viewer, raw, el('footer', 'Displayed by Sitemap Inspector. The file on the website is unchanged.'));
  body.append(main);
  html.append(head, body);
  // Drop processing instructions too, so the replacement cannot trigger an XSL transform.
  while (document.firstChild) document.removeChild(document.firstChild);
  document.appendChild(html);

  const liveResults = new Map();
  const robotsChecker = globalThis.__prettySitemapRobots.createChecker();
  let liveController = null;
  const liveKey = item => item.liveURL;
  const hasFindings = result => result?.notes.some(note => /^(Warning|Error):/.test(note));
  function updateLiveFeedback() {
    const checked = [...new Map(entries.map(item => [item.sourceIndex, liveResults.get(liveKey(item))])).values()].filter(Boolean);
    hasLiveErrors = false;
    hasLiveFindings = false;
    for (const item of liveFindings) {
      const count = checked.filter(item.matches).length;
      item.finding.hidden = !count;
      if (!count) continue;
      hasLiveFindings = true;
      hasLiveErrors ||= item.severity === 'Error';
      item.finding.replaceChildren(el('strong', `${item.severity}: ${item.name}: ${count.toLocaleString()} of ${checked.length.toLocaleString()} checked ${isIndex ? 'sitemap ' : ''}${checked.length === 1 ? 'entry' : 'entries'}.`),
        document.createTextNode(` ${item.advice} Based on live checks; unchecked entries are not included.`));
      if (!item.option) {
        item.option = el('option', undefined, { value: item.kind });
        warningFilter.append(item.option);
      }
      item.option.textContent = `${item.name} (${count.toLocaleString()})`;
    }
    updateSize(requestedSource ? requestedBytes : navigationBytes());
  }
  let filtered = entries;
  let page = 0;
  let sortKey = null;
  let sortDirection = 'ascending';
  const collator = new Intl.Collator('en', { numeric: true, sensitivity: 'base' });
  function updateOrder() {
    const query = input.value.trim().toLowerCase();
    const childFilter = liveFindings.find(item => item.kind === warningFilter.value);
    filtered = entries.filter(item => {
      const result = liveResults.get(liveKey(item));
      const matchesLive = !liveFilter.value || (liveFilter.value === 'findings' ? hasFindings(result) : liveFilter.value === 'incomplete' ? result?.incomplete : !result);
      return matchesLive && (!warningFilter.value || (childFilter ? childFilter.matches(result) : item.feedback.issues.includes(warningFilter.value))) &&
      (!query || [item.url, ...(isVideo ? [item.title, item.description, item.tags] : []), ...(isNews ? [item.newsTitle, item.publication, item.language] : []), ...item.alternates.flatMap(alternate => [alternate.language, alternate.href])]
        .some(value => value.toLowerCase().includes(query)));
    });
    if (sortKey) {
      const direction = sortDirection === 'ascending' ? 1 : -1;
      const column = columns.find(column => column.key === sortKey);
      filtered.sort((a, b) => {
        if (!column.numeric) return direction * collator.compare(a[sortKey], b[sortKey]);
        // Missing or unparseable dates remain last in either direction.
        const aValid = Number.isFinite(a[column.numeric]);
        const bValid = Number.isFinite(b[column.numeric]);
        if (aValid !== bValid) return aValid ? -1 : 1;
        return aValid ? direction * (a[column.numeric] - b[column.numeric]) : 0;
      });
    }
    page = 0;
    render();
  }
  function appendNews(row, item) {
    const title = el('td', undefined, { class: 'news-title' });
    const href = item.feedback.address.fetchable;
    const name = item.newsTitle || item.url || 'Missing address';
    title.append(href ? el('a', name, { href }) : el('span', name));
    if (item.newsTitle && item.url) title.append(el('span', item.url, { class: 'news-address' }));
    if (!isVideo) { appendProtocolWarning(title, item); appendAddressFeedback(title, item); }
    const published = el('td', undefined, { class: 'modified' });
    published.append(Number.isFinite(item.newsTimestamp)
      ? el('time', item.newsPublished.replace('T', ' ').slice(0, 16), { datetime: item.newsPublished, title: item.newsPublished })
      : el('span', item.newsPublished));
    appendDateError(published, item.newsPublished);
    row.append(title, el('td', item.publication), el('td', item.language), published);
  }
  function appendModificationWarning(cell, item) {
    const { kind, sharedCount } = item.feedback;
    if (kind !== 'timestamp') {
      const messages = { missing: 'Warning: missing last modified', 'date-only': 'Warning: date only, no time', invalid: 'Error: invalid last modified' };
      cell.append(el('span', messages[kind], { class: `modification-warning${kind === 'invalid' ? ' feedback-error' : ''}` }));
    }
    if (item.feedback.future) cell.append(el('span', 'Warning: last modified is in the future', { class: 'modification-warning' }));
    if (item.feedback.conflictingDates) cell.append(el('span', 'Warning: conflicting lastmod values for this URL', { class: 'modification-warning' }));
    if (sharedCount) cell.append(el('span', `Warning: lastmod shared by ${sharedCount.toLocaleString()} URLs`, { class: 'modification-warning' }));
  }
  function appendProtocolWarning(cell, item) {
    if (item.feedback.issues.includes('mixed-protocols')) cell.append(el('span', `Warning: ${item.feedback.scheme === 'http:' ? 'HTTP' : 'HTTPS'} in a mixed-protocol sitemap`, { class: 'modification-warning' }));
  }
  function appendAddressFeedback(cell, item) {
    for (const message of item.feedback.address.errors) cell.append(el('span', `Error: ${message}`, { class: 'modification-warning feedback-error' }));
    for (const message of item.feedback.address.warnings) cell.append(el('span', `Warning: ${message}`, { class: 'modification-warning' }));
    if (item.feedback.duplicateCount > 1) cell.append(el('span', `Warning: URL appears ${item.feedback.duplicateCount.toLocaleString()} times`, { class: 'modification-warning' }));
    const result = liveResults.get(liveKey(item));
    if (result) {
      const note = el('div', undefined, { class: 'live-result' });
      note.append(el('span', `Live check${result.status ? `: HTTP ${result.status}` : ''}`, { class: 'live-result-label' }));
      if (result.sitemap?.kind) {
        const checked = result.sitemap;
        note.append(el('span', `${checked.complete ? '' : 'At least '}${checked.entries.toLocaleString()} ${checked.kind === 'sitemapindex' ? 'sitemaps' : 'URLs'} · ${checked.complete ? '' : 'at least '}${formatBytes(checked.bytes)} uncompressed${checked.gzip ? ' · gzip' : ''}`, { class: 'live-sitemap-statistics' }));
      }
      for (const message of result.notes) note.append(el('span', message, { class: `modification-warning${message.startsWith('Error:') ? ' feedback-error' : ''}` }));
      if (!result.notes.length) note.append(el('span', `${result.scope}. No issues found in this check.`));
      if (result.robots) {
        const robots = result.robots;
        const detail = robots.state === 'allowed'
          ? `Googlebot: no crawl restriction found${robots.missing ? ` (HTTP ${robots.status})` : ''}. `
          : 'Googlebot rules: ';
        const source = el('span');
        source.append(document.createTextNode(detail), el('a', 'robots.txt', { href: robots.robotsURL }));
        if (robots.limited) source.append(document.createTextNode(' (first 500 KiB checked, Google’s size limit)'));
        note.append(source);
      }
      cell.append(note);
    }
  }
  function appendDateError(cell, value) {
    if (quality.dateKind(value) === 'invalid') cell.append(el('span', 'Error: invalid publication date', { class: 'modification-warning feedback-error' }));
  }
  const pageSize = 100;
  function render() {
    for (const column of columns) {
      const active = sortKey === column.key;
      if (active) column.th.setAttribute('aria-sort', sortDirection);
      else column.th.removeAttribute('aria-sort');
      column.arrow.textContent = active ? (sortDirection === 'ascending' ? '↑' : '↓') : '↕';
      const nextDirection = active ? (sortDirection === 'ascending' ? 'descending' : 'ascending')
        : (column.descendingFirst ? 'descending' : 'ascending');
      column.button.title = `Sort ${column.label.toLowerCase()} ${nextDirection}`;
    }
    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, totalPages - 1);
    const fragment = document.createDocumentFragment();
    for (const item of filtered.slice(page * pageSize, (page + 1) * pageSize)) {
      const row = el('tr');
      if (isVideo) {
        const thumbnail = el('td', undefined, { class: 'thumbnail-cell' });
        const destination = safeLink(item.player) || safeLink(item.content);
        const imageUrl = safeLink(item.thumbnail);
        const fallback = el('span', item.video ? 'No thumbnail' : 'No video', { class: 'thumbnail-fallback' });
        const preview = destination ? el('a', undefined, { href: destination, 'aria-label': `Open video: ${item.title || item.url}`, rel: 'noreferrer' }) : el('span');
        if (imageUrl) {
          const image = el('img', undefined, { src: imageUrl, alt: item.title ? `Thumbnail: ${item.title}` : 'Video thumbnail',
            width: '160', height: '90', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
          image.addEventListener('error', () => image.replaceWith(fallback), { once: true });
          preview.append(image);
        } else preview.append(fallback);
        thumbnail.append(preview);
        const title = el('td', undefined, { class: 'video-title' });
        const href = item.feedback.address.fetchable;
        const name = item.title || item.url || 'Missing title';
        title.append(href ? el('a', name, { href }) : el('span', name));
        if (item.title && item.url) title.append(el('span', item.url, { class: 'video-address' }));
        appendModificationWarning(title, item);
        appendProtocolWarning(title, item);
        appendAddressFeedback(title, item);
        const description = el('td', undefined, { class: 'video-description' });
        if (item.description.length > 200) {
          const details = el('details');
          details.append(el('summary', item.description.slice(0, 200) + '…'), el('p', item.description));
          description.append(details);
        } else description.textContent = item.description || 'Not provided';
        const duration = Number.isFinite(item.duration)
          ? `${Math.floor(item.duration / 60)}:${String(item.duration % 60).padStart(2, '0')}` : 'Not provided';
        const published = el('td', undefined, { class: 'modified' });
        published.append(Number.isFinite(item.publishedTimestamp)
          ? el('time', item.published.replace('T', ' ').slice(0, 16), { datetime: item.published, title: item.published })
          : el('span', item.published || 'Not provided'));
        appendDateError(published, item.published);
        row.append(thumbnail, title, description, el('td', item.tags), el('td', duration), published);
        if (isNews) appendNews(row, item);
      } else {
        if (isNews) appendNews(row, item);
        else {
          const address = el('td');
          const href = item.feedback.address.fetchable;
          address.append(href ? el('a', item.url, { href, ...(isIndex ? { 'data-sitemap-follow': '', 'data-sitemap-index-entry': '' } : {}) }) : el('span', item.url || 'Missing address'));
          appendProtocolWarning(address, item);
          appendAddressFeedback(address, item);
          row.append(address);
        }
        if (hasImages) row.append(el('td', item.imageCount.toLocaleString(), { class: 'image-count' }));
        const modified = el('td', item.modified, { class: 'modified' });
        appendModificationWarning(modified, item);
        row.append(modified);
      }
      if (hasAlternates) {
        const cell = el('td', undefined, { class: 'language-alternates' });
        if (item.alternates.length) {
          const list = el('ul', undefined, { 'aria-label': 'Alternate language versions' });
          for (const alternate of item.alternates) {
            const li = el('li');
            const href = safeLink(alternate.href);
            const label = alternate.language || alternate.href;
            li.append(href ? el('a', label, { href, title: alternate.href,
              ...(alternate.language ? { hreflang: alternate.language } : {}) }) : el('span', label));
            list.append(li);
          }
          cell.append(list);
        }
        row.append(cell);
      }
      fragment.append(row);
    }
    tbody.replaceChildren(fragment);
    const unit = isIndex ? 'sitemaps' : isVideo ? (videoCount === entries.length ? 'videos' : 'entries') : isNews ? (entries.every(item => item.news) ? 'articles' : 'entries') : 'pages';
    count.textContent = `${filtered.length.toLocaleString()} of ${entries.length.toLocaleString()} ${unit}${isVideo ? ` across ${pages.length.toLocaleString()} pages` : ''}`;
    empty.hidden = filtered.length !== 0;
    empty.textContent = entries.length ? ((warningFilter.value || liveFilter.value) ? 'No entries match your search and feedback filters.' : isVideo ? 'No videos match your search.' : isNews ? 'No news entries match your search.' : 'No addresses match your search.') : 'This sitemap has no entries.';
    tableWrap.hidden = filtered.length === 0;
    nav.hidden = filtered.length <= pageSize;
    pageLabel.textContent = `Page ${page + 1} of ${totalPages}`;
    previous.disabled = page === 0;
    next.disabled = page >= totalPages - 1;
    const remaining = pendingLiveURLs();
    liveStart.disabled = Boolean(liveController) || !remaining.length;
    liveStart.textContent = remaining.length ? `Check ${Math.min(100, remaining.length).toLocaleString()}${remaining.length === 1 ? ' URL' : ' URLs'}` : 'Check URLs';
    liveStart.title = remaining.length ? 'Check the next batch of filtered URLs' : 'No unchecked, valid URLs match the current filters';
  }
  function pendingLiveURLs() {
    return [...new Set(filtered.map(liveKey).filter(key => key && !liveResults.has(key)))];
  }
  liveStart.addEventListener('click', async () => {
    if (liveController) return;
    const urls = pendingLiveURLs().slice(0, 100);
    if (!urls.length) return;
    const controller = new AbortController();
    liveController = controller;
    liveStop.hidden = false;
    let cursor = 0, completed = 0, rateLimited = false;
    liveStatus.textContent = `Checking 0 of ${urls.length} URLs…`;
    render();
    const worker = async () => {
      while (!controller.signal.aborted && cursor < urls.length) {
        const url = urls[cursor++];
        try {
          const robots = await robotsChecker.check(url, { signal: controller.signal });
          if (controller.signal.aborted) break;
          const response = robots.status === 429
            ? { notes: [], incomplete: true }
            : await live.check(url, { signal: controller.signal, isIndex });
          const result = globalThis.__prettySitemapRobots.annotate(response, robots);
          if (controller.signal.aborted) break;
          liveResults.set(url, result);
          updateLiveFeedback();
          completed++;
          if (result.status === 429 || result.robots?.status === 429) { rateLimited = true; controller.abort(); }
          liveStatus.textContent = `Checked ${completed} of ${urls.length} URLs in this batch.`;
          if (liveFilter.value || warningFilter.value) updateOrder(); else render();
        } catch (error) {
          if (!controller.signal.aborted) {
            liveResults.set(url, { notes: ['Could not check this URL'], incomplete: true });
            completed++;
          }
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(3, urls.length) }, worker));
    liveController = null;
    liveStop.hidden = true;
    updateLiveFeedback();
    const results = [...liveResults.values()];
    const findings = results.filter(hasFindings).length;
    const incomplete = results.filter(result => result.incomplete).length;
    liveStatus.textContent = `${rateLimited ? 'Paused after HTTP 429. ' : controller.signal.aborted ? 'Stopped. ' : ''}${results.length.toLocaleString()} distinct URLs checked; ${findings.toLocaleString()} with findings; ${incomplete.toLocaleString()} could not be fully checked. Results stay in this tab until refresh.`;
    updateOrder();
  });
  liveStop.addEventListener('click', () => liveController?.abort());
  window.addEventListener('pagehide', () => liveController?.abort());
  liveFilter.addEventListener('change', updateOrder);
  input.addEventListener('input', updateOrder);
  warningFilter.addEventListener('change', updateOrder);
  for (const column of columns) {
    column.button.addEventListener('click', () => {
      sortDirection = sortKey === column.key ? (sortDirection === 'ascending' ? 'descending' : 'ascending')
        : (column.descendingFirst ? 'descending' : 'ascending');
      sortKey = column.key;
      updateOrder();
    });
  }
  previous.addEventListener('click', () => { page--; render(); });
  next.addEventListener('click', () => { page++; render(); });
  toggle.addEventListener('click', () => {
    const showRaw = raw.hidden;
    raw.hidden = !showRaw;
    viewer.hidden = showRaw;
    toggle.textContent = showRaw ? 'Show table' : 'Show XML';
    toggle.setAttribute('aria-expanded', String(showRaw));
  });
  render();
  globalThis.__prettySitemapRendered = true;
  globalThis.__prettySitemapBreadcrumbs?.mount(main, main.firstChild, ({ parentIndex }) => {
    nestedIndex = isIndex && Boolean(parentIndex);
    nestedFinding.hidden = !nestedIndex;
    nestedFinding.replaceChildren();
    if (nestedIndex) {
      nestedFinding.append(el('strong', 'Error: nested sitemap index. '),
        document.createTextNode('This index was linked from another sitemap index: '),
        el('a', parentIndex, { href: parentIndex }),
        document.createTextNode('. Google does not support indexes within indexes. List the individual sitemap files in the parent index, or submit this index separately.'));
    }
    updateSize(requestedSource ? requestedBytes : navigationBytes());
  });
})();
