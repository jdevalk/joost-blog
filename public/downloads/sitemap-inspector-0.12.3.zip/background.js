/* Temporary navigation trails. No browsing-history permission or remote requests. */
'use strict';
const queues = new Map();
const prefix = 'sitemap-trail:';
const maxTrail = 40;
const maxDocuments = 40;
const pendingLifetime = 120000;

function safeURL(value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.href.length > 8192) return null;
    return url.href;
  } catch { return null; }
}
function queue(tabId, task) {
  const next = (queues.get(tabId) || Promise.resolve()).catch(() => {}).then(task);
  queues.set(tabId, next);
  next.finally(() => { if (queues.get(tabId) === next) queues.delete(tabId); }).catch(() => {});
  return next;
}
async function read(tabId) {
  return (await chrome.storage.session.get(prefix + tabId))[prefix + tabId] || { documents: [] };
}
async function write(tabId, state) {
  await chrome.storage.session.set({ [prefix + tabId]: state });
}
function followed(trail, url) {
  const ancestor = trail.indexOf(url);
  return ancestor < 0 ? [...trail, url].slice(-maxTrail) : trail.slice(0, ancestor + 1);
}
function matchingPending(pending, url) {
  return pending?.url === url && Date.now() - pending.at < pendingLifetime;
}
async function handle(message, sender) {
  const tabId = sender.tab.id;
  const url = safeURL(sender.url);
  if (!url || !sender.documentId) return null;
  const state = await read(tabId);
  const document = state.documents.find(item => item.id === sender.documentId);
  if (message.action === 'visit') {
    let trail;
    let parentIndex = null;
    if (matchingPending(state.pending, url)) { trail = state.pending.trail; parentIndex = state.pending.parentIndex; }
    else if (document?.url === url) { trail = document.trail; parentIndex = document.parentIndex; }
    else {
      // Reload/back/forward can create a new document; reuse that URL's last trail.
      if (['reload', 'back_forward'].includes(message.navigation)) {
        const previous = state.documents.findLast(item => item.url === url);
        trail = previous?.trail;
        parentIndex = previous?.parentIndex;
      }
      if (!trail && sender.tab.openerTabId !== undefined) {
        await queues.get(sender.tab.openerTabId)?.catch(() => {});
        const parent = await read(sender.tab.openerTabId);
        if (matchingPending(parent.hint, url)) { trail = parent.hint.trail; parentIndex = parent.hint.parentIndex; }
      }
    }
    trail ||= [url];
    delete state.pending;
    state.documents = state.documents.filter(item => item.id !== sender.documentId);
    state.documents.push({ id: sender.documentId, url, trail, parentIndex });
    state.documents = state.documents.slice(-maxDocuments);
    await write(tabId, state);
    return { trail, parentIndex };
  }
  const target = safeURL(message.url);
  if (!target || !document || document.url !== url) return null;
  const pending = { url: target, trail: followed(document.trail, target), at: Date.now(),
    parentIndex: message.fromIndexEntry === true ? url : null };
  if (message.action === 'hint') {
    state.hint = pending;
    await write(tabId, state);
    return { saved: true };
  }
  if (message.action !== 'follow') return null;
  if (message.newTab) {
    // Save before loading the destination, so its content script cannot race us.
    const tab = await chrome.tabs.create({ url: 'about:blank', active: Boolean(message.active), openerTabId: tabId });
    try {
      await write(tab.id, { documents: [], pending });
      await chrome.tabs.update(tab.id, { url: target });
    } catch (error) {
      await chrome.tabs.remove(tab.id).catch(() => {});
      throw error;
    }
    return { opened: true };
  }
  state.pending = pending;
  await write(tabId, state);
  return { saved: true };
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'sitemap-trail' || sender.frameId !== 0 || sender.tab?.id === undefined) return;
  queue(sender.tab.id, () => handle(message, sender)).then(reply, () => reply(null));
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => {
  queue(tabId, () => chrome.storage.session.remove(prefix + tabId)).catch(() => {});
});
