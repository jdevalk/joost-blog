(() => {
  'use strict';
  const status = document.getElementById('status');
  const retry = document.getElementById('retry');
  const messages = {
    unsupported: 'Open an XML sitemap or robots.txt, then click this button.',
    'not-sitemap': 'Open an XML sitemap or a plain-text robots.txt file, then try again.',
    unavailable: 'The sitemap could not be loaded. Check your connection or website access and try again.',
    changed: 'The page changed while loading. Try again on the sitemap tab.'
  };
  async function styleSitemap() {
    retry.hidden = true;
    status.textContent = 'Opening the sitemap view…';
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) {
        status.textContent = messages.unsupported;
        return;
      }
      const [prepared] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, files: ['manual-source.js']
      });
      const result = prepared?.result;
      if (result?.status === 'robots' && prepared.documentId) {
        await chrome.scripting.insertCSS({ target: { tabId: tab.id, documentIds: [prepared.documentId] }, files: ['viewer.css'] });
        const [linked] = await chrome.scripting.executeScript({
          target: { tabId: tab.id, documentIds: [prepared.documentId] }, files: ['breadcrumbs.js', 'robots.js']
        });
        if (!linked?.result) throw new Error('Robots file changed');
        window.close();
        return;
      }
      if (result?.status === 'already') { window.close(); return; }
      if (result?.status !== 'ready' || !prepared.documentId) {
        status.textContent = messages[result?.status] || messages.unavailable;
        retry.hidden = !['unavailable', 'changed'].includes(result?.status);
        return;
      }
      // Bind all remaining work to this exact document, even if the user navigates.
      const target = { tabId: tab.id, documentIds: [prepared.documentId] };
      await chrome.scripting.insertCSS({ target, files: ['viewer.css'] });
      await chrome.scripting.executeScript({ target, files: ['breadcrumbs.js', 'quality.js', 'vendor/sax.js', 'live-checks.js', 'robots-policy.js', 'content.js'] });
      const [rendered] = await chrome.scripting.executeScript({
        target, func: () => globalThis.__prettySitemapRendered === true && document.documentElement.id === 'pretty-sitemap'
      });
      if (!rendered?.result) throw new Error('View not rendered');
      window.close();
    } catch {
      status.textContent = messages.unavailable;
      retry.hidden = false;
    }
  }
  retry.addEventListener('click', styleSitemap);
  styleSitemap();
})();
