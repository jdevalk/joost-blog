(() => {
  'use strict';
  if (globalThis.__prettySitemapBreadcrumbs) return;
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const send = async data => {
    try { return await chrome.runtime.sendMessage({ type: 'sitemap-trail', ...data }); } catch { return null; }
  };
  let nav;
  let onVisit;
  let ready = Promise.resolve();
  const node = (tag, text) => {
    const element = document.createElementNS(XHTML, tag);
    if (text !== undefined) element.textContent = text;
    return element;
  };
  function label(address) {
    const url = new URL(address);
    const filename = url.pathname.split('/').filter(Boolean).pop() || url.hostname;
    try { return decodeURIComponent(filename) + url.search; } catch { return filename + url.search; }
  }
  async function refresh() {
    const result = await send({ action: 'visit', navigation: performance.getEntriesByType('navigation')[0]?.type });
    if (!result?.trail?.length || !nav?.isConnected) return;
    onVisit?.(result);
    const list = node('ol');
    result.trail.forEach((address, index) => {
      const item = node('li');
      const current = index === result.trail.length - 1;
      const link = node(current ? 'span' : 'a', label(address));
      link.title = address;
      if (current) link.setAttribute('aria-current', 'page');
      else {
        link.setAttribute('href', address);
        link.setAttribute('data-sitemap-follow', '');
      }
      item.append(link);
      list.append(item);
    });
    nav.replaceChildren(list);
    nav.hidden = result.trail.length < 2;
  }
  globalThis.__prettySitemapBreadcrumbs = {
    mount(parent, before = parent.firstChild, visitCallback) {
      if (nav?.isConnected) return;
      onVisit = visitCallback;
      nav = node('nav');
      nav.id = 'pretty-sitemap-breadcrumbs';
      nav.setAttribute('aria-label', 'Sitemap trail');
      nav.hidden = true;
      parent.insertBefore(nav, before);
      ready = refresh();
    }
  };
  function linkFrom(event) {
    if (!event.isTrusted || !nav?.isConnected) return null;
    return event.target.closest?.('a[data-sitemap-follow]');
  }
  async function follow(event) {
    const link = linkFrom(event);
    if (!link || event.defaultPrevented || event.altKey || (event.button !== 0 && event.button !== 1)) return;
    const newTab = event.button === 1 || event.ctrlKey || event.metaKey;
    // Preserve the browser's native new-window behavior.
    if (event.shiftKey && !newTab) {
      await ready;
      await send({ action: 'hint', url: link.href, fromIndexEntry: link.hasAttribute('data-sitemap-index-entry') });
      return;
    }
    event.preventDefault();
    await ready;
    const result = await send({ action: 'follow', url: link.href, fromIndexEntry: link.hasAttribute('data-sitemap-index-entry'), newTab, active: event.shiftKey });
    if (result?.opened) return;
    if (newTab) {
      const fallback = node('a');
      fallback.href = link.href;
      fallback.target = '_blank';
      fallback.rel = 'noopener';
      fallback.click();
    } else location.assign(link.href);
  }
  document.addEventListener('click', follow);
  document.addEventListener('auxclick', event => { if (event.button === 1) follow(event); });
  document.addEventListener('contextmenu', async event => {
    const link = linkFrom(event);
    if (!link) return;
    await ready;
    await send({ action: 'hint', url: link.href, fromIndexEntry: link.hasAttribute('data-sitemap-index-entry') });
  });
  window.addEventListener('pageshow', event => { if (event.persisted && nav?.isConnected) ready = refresh(); });
})();
