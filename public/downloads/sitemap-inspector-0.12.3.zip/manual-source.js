(async () => {
  'use strict';
  if (globalThis.__prettySitemapRendered && document.documentElement.id === 'pretty-sitemap') {
    return { status: 'already' };
  }
  if (location.pathname === '/robots.txt' && document.contentType === 'text/plain') {
    return { status: 'robots' };
  }
  delete globalThis.__prettySitemapRequestedSource;
  delete globalThis.__prettySitemapRequestedBytes;
  delete globalThis.__prettySitemapRequestedContentType;
  const pageUrl = location.href;
  if (!['https:', 'http:'].includes(location.protocol)) return { status: 'unsupported' };
  try {
    // Read the original XML again: Chrome has replaced it with HTML after XSLT.
    const response = await fetch(pageUrl, {
      credentials: 'same-origin', redirect: 'error', signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) return { status: 'unavailable' };
    const type = response.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
    if (!['application/xml', 'text/xml', 'text/plain'].includes(type) && !/^[^/]+\/[^;\s]+\+xml$/.test(type || '')) return { status: 'not-sitemap' };
    // Fetch exposes the decoded body, so gzip/Brotli transfers count at their
    // uncompressed size, including the XML declaration, comments and whitespace.
    const bytes = await response.arrayBuffer();
    const xml = new DOMParser().parseFromString(new TextDecoder().decode(bytes), 'application/xml');
    const source = xml.documentElement;
    if (location.href !== pageUrl) return { status: 'changed' };
    if (xml.getElementsByTagName('parsererror').length ||
        source.namespaceURI !== 'http://www.sitemaps.org/schemas/sitemap/0.9' ||
        !['urlset', 'sitemapindex'].includes(source.localName)) return { status: 'not-sitemap' };
    globalThis.__prettySitemapRequestedSource = source;
    globalThis.__prettySitemapRequestedBytes = bytes.byteLength;
    globalThis.__prettySitemapRequestedContentType = type;
    return { status: 'ready' };
  } catch {
    return { status: 'unavailable' };
  }
})();
