(() => {
  'use strict';
  const MAX_ENTRIES = 50000;
  const MAX_BYTES = 52428800;
  const MAX_NEWS = 1000;

  // Validate the calendar and W3C date/time syntax, rather than Date.parse's
  // permissive parsing (which accepts local dates and rolls February 30 forward).
  function dateKind(value) {
    if (!value) return 'missing';
    const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?(Z|[+-]\d{2}:\d{2}))?$/.exec(value);
    if (!match) return 'invalid';
    const [, year, month, day, hour, minute, second, , zone] = match;
    const y = Number(year), m = Number(month), d = Number(day);
    const leap = y % 4 === 0 && (y % 100 !== 0 || y % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (!y || m < 1 || m > 12 || d < 1 || d > days[m - 1]) return 'invalid';
    if (hour === undefined) return 'date-only';
    if (Number(hour) > 23 || Number(minute) > 59 || Number(second || 0) > 59) return 'invalid';
    if (zone !== 'Z') {
      const hours = Number(zone.slice(1, 3)), minutes = Number(zone.slice(4));
      if (hours > 14 || minutes > 59 || (hours === 14 && minutes !== 0)) return 'invalid';
    }
    return 'timestamp';
  }

  function protocol(value) {
    if (!/^https?:\/\//i.test(value)) return '';
    try { return new URL(value).protocol; } catch { return ''; }
  }

  function inspectURL(value) {
    const errors = [], warnings = [];
    let parsed;
    if (!value) errors.push('Missing loc address');
    else {
      if ([...value].length >= 2048) errors.push('Address must be shorter than 2,048 characters');
      if (!/^https?:\/\/[^/]/i.test(value)) errors.push('Use an absolute HTTP or HTTPS address');
      if (/[\s\\<>"\x00-\x1f\x7f]/u.test(value) || /%(?![\da-f]{2})/i.test(value)) errors.push('Address contains unescaped or malformed characters');
      try { parsed = new URL(value); } catch { errors.push('Malformed address'); }
      if (parsed && ['http:', 'https:'].includes(parsed.protocol)) {
        if (parsed.username || parsed.password) warnings.push('Address contains embedded credentials');
        if (value.includes('#')) warnings.push('Address contains a fragment');
        if ([...parsed.searchParams.keys()].some(key => /^(utm_.+|gclid|dclid|fbclid|msclkid|_ga|mc_cid|mc_eid)$/i.test(key))) warnings.push('Address contains tracking parameters');
      }
    }
    return { errors, warnings, key: errors.length ? null : parsed?.href || null,
      fetchable: !errors.length && parsed && !parsed.username && !parsed.password ? parsed.href : null };
  }

  function analyze(records, now = Date.now()) {
    const shared = new Map();
    const duplicates = new Map();
    const protocols = { 'http:': 0, 'https:': 0 };
    const items = records.map(record => {
      const modified = (record.modified || '').trim();
      const kind = dateKind(modified);
      const scheme = protocol(record.url);
      const address = inspectURL(record.url);
      if (address.key) {
        if (!duplicates.has(address.key)) duplicates.set(address.key, { count: 0, dates: new Set() });
        const duplicate = duplicates.get(address.key);
        duplicate.count++;
        // Missing values are not contradictory claims about when a page changed.
        if (modified) duplicate.dates.add(kind === 'timestamp' ? `time:${Date.parse(modified)}` : modified);
      }
      if (scheme) protocols[scheme]++;
      if (scheme && ['date-only', 'timestamp'].includes(kind)) {
        if (!shared.has(modified)) shared.set(modified, new Set());
        shared.get(modified).add(new URL(record.url).href);
      }
      const invalidDates = (record.dates || []).filter(date => date.value && dateKind(date.value.trim()) === 'invalid');
      // Date-only values have no timezone: allow a full day plus clock tolerance.
      const future = ['date-only', 'timestamp'].includes(kind) && Date.parse(modified) > now + (kind === 'date-only' ? 86400000 : 300000);
      return { kind, modified, scheme, address, future, invalidDates, issues: [
        ...(address.errors.length ? ['invalid-url'] : []),
        ...(address.warnings.length ? ['suspicious-url'] : []),
        ...(future ? ['future-lastmod'] : []),
        ...(record.ignoredFields?.length ? ['ignored-fields'] : []),
        ...(kind === 'missing' || kind === 'date-only' ? [kind] : []),
        ...(kind === 'invalid' || invalidDates.length ? ['invalid-date'] : [])
      ] };
    });
    const mixed = protocols['http:'] > 0 && protocols['https:'] > 0;
    const repeated = new Map([...shared].filter(([, urls]) => urls.size > 10));
    const counts = {};
    for (const item of items) {
      const duplicate = duplicates.get(item.address.key);
      item.duplicateCount = duplicate?.count || 0;
      item.conflictingDates = item.duplicateCount > 1 && duplicate.dates.size > 1;
      if (item.duplicateCount > 1) item.issues.push('duplicate-url');
      if (item.conflictingDates) item.issues.push('conflicting-lastmod');
      item.sharedCount = item.scheme ? repeated.get(item.modified)?.size || 0 : 0;
      if (item.sharedCount) item.issues.push('repeated-lastmod');
      if (mixed && item.scheme) item.issues.push('mixed-protocols');
      for (const issue of item.issues) counts[issue] = (counts[issue] || 0) + 1;
    }
    const newsCount = records.reduce((count, record) => count + (record.newsCount || 0), 0);
    return { items, counts, protocols, repeatedGroups: repeated.size, tooManyEntries: records.length > MAX_ENTRIES,
      newsCount, tooManyNews: newsCount > MAX_NEWS };
  }

  function sizeIssue(bytes) {
    if (!Number.isSafeInteger(bytes) || bytes <= 0) return 'unknown';
    return bytes > MAX_BYTES ? 'too-large' : '';
  }

  globalThis.__prettySitemapQuality = Object.freeze({ MAX_ENTRIES, MAX_BYTES, MAX_NEWS, dateKind, inspectURL, analyze, sizeIssue });
})();
