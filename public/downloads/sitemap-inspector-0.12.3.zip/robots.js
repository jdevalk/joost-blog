(() => {
  'use strict';
  // Keep Chrome's plain-text view; only add links to sitemap declarations.
  if (location.pathname !== '/robots.txt' || document.contentType !== 'text/plain') return false;
  const pre = document.querySelector('body > pre');
  if (!pre) return false;
  if (pre.dataset.prettySitemapRobots === 'true') return true;
  const source = pre.textContent;
  const fragment = document.createDocumentFragment();
  const declarations = /^([\uFEFF\t ]*sitemap[\t ]*:[\t ]*)(https?:\/\/[^\s#]+)([\t ]*(?:#[^\r\n]*)?)$/gim;
  let cursor = 0;
  let linked = false;
  for (const match of source.matchAll(declarations)) {
    let url;
    try { url = new URL(match[2]); } catch { continue; }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) continue;
    const start = match.index + match[1].length;
    fragment.append(document.createTextNode(source.slice(cursor, start)));
    const link = document.createElement('a');
    link.href = url.href;
    link.setAttribute('data-sitemap-follow', '');
    link.textContent = match[2];
    fragment.append(link);
    cursor = start + match[2].length;
    linked = true;
  }
  if (linked) {
    fragment.append(document.createTextNode(source.slice(cursor)));
    pre.replaceChildren(fragment);
  }
  pre.dataset.prettySitemapRobots = 'true';
  globalThis.__prettySitemapBreadcrumbs?.mount(pre.parentNode, pre);
  return true;
})();
