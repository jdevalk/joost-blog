(() => {
  'use strict';
  const MAX_BYTES = 1048576;
  const TIMEOUT = 10000;
  const noindex = value => /(?:^|[\s,;])(?:noindex|none)(?:$|[\s,;])/i.test(value);
  function headerNoindex(value) {
    let agent = '';
    return value.split(',').some(part => {
      const scope = /^\s*([\w-]+):\s*(.*)$/.exec(part);
      if (scope) {
        const name = scope[1].toLowerCase();
        if (['unavailable_after', 'max-snippet', 'max-image-preview', 'max-video-preview'].includes(name)) return false;
        agent = name;
        part = scope[2];
      }
      return ['', 'robots', 'googlebot'].includes(agent) && noindex(part);
    });
  }
  function normalized(value, base) {
    try {
      const url = new URL(value, base);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return null;
      url.hash = '';
      return url.href;
    } catch { return null; }
  }
  function metadata(html, finalURL, headerRobots, headerLink) {
    // Template contents stay inert: parsing does not run scripts or request images,
    // frames, styles, or other resources from the inspected page.
    const doc = document.implementation.createHTMLDocument('');
    const template = doc.createElement('template');
    template.innerHTML = html;
    const fragment = template.content;
    const base = normalized(fragment.querySelector('base[href]')?.getAttribute('href') || finalURL, finalURL) || finalURL;
    const blocked = headerNoindex(headerRobots || '') || Array.from(fragment.querySelectorAll('meta[name]')).some(meta =>
      ['robots', 'googlebot'].includes(meta.getAttribute('name').trim().toLowerCase()) && noindex(meta.getAttribute('content') || ''));
    const canonicals = [];
    for (const link of fragment.querySelectorAll('link[rel][href]')) {
      if (link.getAttribute('rel').toLowerCase().split(/\s+/).includes('canonical')) canonicals.push(normalized(link.getAttribute('href'), base));
    }
    for (const part of (headerLink || '').split(/,(?=\s*<)/)) {
      const target = /<([^>]+)>/.exec(part);
      const rel = /;\s*rel\s*=\s*(?:"([^"]*)"|'([^']*)'|([^;\s]+))/i.exec(part);
      if (target && rel && (rel[1] || rel[2] || rel[3]).toLowerCase().split(/\s+/).includes('canonical')) canonicals.push(normalized(target[1], finalURL));
    }
    return { blocked, canonicals: [...new Set(canonicals)] };
  }
  const MAX_SITEMAP_BYTES = 52428800;
  const MAX_ENTRIES = 50000;
  const SITEMAP_TIMEOUT = 30000;
  const NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';
  // Fetch already decodes HTTP Content-Encoding. Sniff actual bytes so .xml.gz
  // files are decompressed once, regardless of filename or server headers.
  async function sitemapStream(response) {
    if (!response.body) throw new Error('Empty response');
    const source = response.body.getReader();
    const prefix = [];
    let length = 0, released = false;
    const release = () => { if (!released) { source.releaseLock(); released = true; } };
    try {
      while (length < 2) {
        const { done, value } = await source.read();
        if (done) break;
        if (value.length) { prefix.push(value); length += value.length; }
      }
    } catch (error) { release(); throw error; }
    const first = prefix[0]?.[0];
    const second = prefix[0]?.length > 1 ? prefix[0][1] : prefix[1]?.[0];
    const gzip = first === 0x1f && second === 0x8b;
    const stream = new ReadableStream({
      async pull(controller) {
        try {
          if (prefix.length) { controller.enqueue(prefix.shift()); return; }
          const { done, value } = await source.read();
          if (done) { release(); controller.close(); } else controller.enqueue(value);
        } catch (error) { release(); controller.error(error); }
      },
      async cancel(reason) { try { await source.cancel(reason); } finally { release(); } }
    }, { highWaterMark: 0 });
    return { stream: gzip ? stream.pipeThrough(new DecompressionStream('gzip')) : stream, gzip };
  }
  async function inspectSitemap(response, progress) {
    const decoded = await sitemapStream(response);
    progress.gzip = decoded.gzip;
    const reader = decoded.stream.getReader();
    const decoder = new TextDecoder('utf-8', { fatal: true });
    const parser = globalThis.sax.parser(true, { xmlns: true, strictEntities: true });
    let depth = 0;
    parser.onerror = () => { throw new Error('Invalid XML'); };
    parser.ondoctype = () => { throw new Error('DOCTYPE is not supported'); };
    parser.onopentag = node => {
      if (++depth > 256) throw new Error('XML nesting too deep');
      if (depth === 1) {
        if (node.uri !== NS || !['urlset', 'sitemapindex'].includes(node.local)) throw new Error('Not a sitemap');
        progress.kind = node.local;
      } else if (depth === 2 && node.uri === NS && node.local === (progress.kind === 'urlset' ? 'url' : 'sitemap')) progress.entries++;
    };
    parser.onclosetag = () => { depth--; };
    const parse = text => {
      // Small writes bound parser buffers. Comment text is irrelevant to counts;
      // discard its payload while retaining the parser's comment syntax state.
      for (let i = 0; i < text.length; i += 16384) {
        parser.write(text.slice(i, i + 16384));
        parser.comment = '';
      }
    };
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          parse(decoder.decode());
          parser.close();
          if (!progress.kind) throw new Error('Empty sitemap');
          progress.complete = true;
          return;
        }
        const remaining = MAX_SITEMAP_BYTES + 1 - progress.bytes;
        const chunk = value.subarray(0, remaining);
        progress.bytes += chunk.byteLength;
        progress.overSize = progress.bytes > MAX_SITEMAP_BYTES;
        parse(decoder.decode(chunk, { stream: true }));
        if (progress.overSize) return;
      }
    } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
  }
  function sitemapResult(progress, notes, status, reason) {
    if (progress.kind === 'sitemapindex') notes.push('Error: nested sitemap index. Google does not support indexes within indexes. List the individual sitemap files in this index, or submit the child index separately.');
    if (progress.entries > MAX_ENTRIES) notes.push(`Error: too many entries (${progress.complete ? '' : 'at least '}${progress.entries.toLocaleString()}). The limit is 50,000 ${progress.kind === 'sitemapindex' ? 'sitemaps per index' : 'URLs per sitemap'}. Split this file into smaller files.`);
    if (progress.overSize) notes.push('Error: sitemap exceeds 50 MB (52,428,800 bytes) uncompressed. Split this file into smaller files.');
    if (!progress.complete) notes.push(`Sitemap check incomplete: ${reason || (progress.overSize ? 'stopped after exceeding the uncompressed size limit' : 'response is not readable, well-formed sitemap XML')}.`);
    return { notes, status, incomplete: !progress.complete,
      sitemap: { ...progress }, scope: 'HTTP status, XML structure, entry count and uncompressed size checked' };
  }
  async function check(value, { signal, isIndex = false } = {}) {
    const url = normalized(value);
    if (!url) return { notes: ['Could not check: invalid URL or embedded credentials'], incomplete: true };
    const controller = new AbortController();
    const abort = () => controller.abort();
    if (signal?.aborted) throw new DOMException('Stopped', 'AbortError');
    signal?.addEventListener('abort', abort, { once: true });
    const timeout = setTimeout(abort, isIndex ? SITEMAP_TIMEOUT : TIMEOUT);
    let response;
    const progress = { kind: null, entries: 0, bytes: 0, complete: false, overSize: false, gzip: false };
    const notes = [];
    let incomplete = false;
    try {
      response = await fetch(url, { signal: controller.signal, credentials: 'omit', referrerPolicy: 'no-referrer', cache: 'no-store', redirect: 'follow' });
      if (response.redirected) notes.push('Warning: URL redirects');
      const status = response.status;
      if ([401, 403, 429].includes(status)) return { notes: [...notes, `Could not check: HTTP ${status}`], incomplete: true, status };
      if (!response.ok) return { notes: [...notes, `Error: HTTP ${status}`], status };
      if (isIndex) {
        await inspectSitemap(response, progress);
        return sitemapResult(progress, notes, status);
      }
      const type = (response.headers.get('content-type') || '').split(';')[0].toLowerCase().trim();
      const isHTML = ['text/html', 'application/xhtml+xml'].includes(type);
      let html = '';
      if (isHTML && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let bytes = 0;
        try {
          while (true) {
            const { done, value: chunk } = await reader.read();
            if (done) { html += decoder.decode(); break; }
            const remaining = MAX_BYTES - bytes;
            html += decoder.decode(chunk.subarray(0, remaining), { stream: true });
            bytes += chunk.byteLength;
            if (bytes > MAX_BYTES) { incomplete = true; break; }
          }
        } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
      }
      const meta = metadata(html, response.url || url, response.headers.get('x-robots-tag'), response.headers.get('link'));
      if (meta.blocked) notes.push('Warning: noindex directive');
      if (meta.canonicals.includes(null)) notes.push('Warning: invalid canonical URL');
      if (meta.canonicals.some(canonical => canonical && canonical !== url)) notes.push('Warning: canonical points to another URL');
      if (incomplete) notes.push('Metadata check incomplete: response exceeds 1 MB');
      if (response.type === 'cors') {
        incomplete = true;
        notes.push('Metadata check incomplete: cross-origin response headers may be hidden');
      }
      return { notes, status, incomplete, scope: isHTML ? 'Response HTML and headers checked' : 'Headers checked; response is not HTML' };
    } catch {
      if (signal?.aborted) throw new DOMException('Stopped', 'AbortError');
      if (isIndex && response?.ok) return sitemapResult(progress, notes, response.status, controller.signal.aborted ? 'request timed out' : undefined);
      return { notes: [...notes, controller.signal.aborted ? 'Could not check: request timed out' : 'Could not check: network or browser access restrictions'], incomplete: true };
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', abort);
      await response?.body?.cancel().catch(() => {});
    }
  }
  globalThis.__prettySitemapLive = Object.freeze({ check, normalized, metadata, headerNoindex, inspectSitemap });
})();
