(() => {
  'use strict';
  // Google Search's web crawler rules, applied to the response available to this browser.
  // https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec
  const MAX_BYTES = 500 * 1024;
  const normalize = value => value.replace(/[^\x00-\x7F]/gu, char => encodeURIComponent(char))
    .replace(/%[\da-f]{2}/gi, escape => escape.toUpperCase());

  function parse(text) {
    const groups = [];
    let group = null, hasRules = false;
    for (const [index, raw] of text.replace(/^\uFEFF/, '').split(/\r\n|\n|\r/).entries()) {
      const line = raw.split('#')[0].trim();
      const colon = line.indexOf(':');
      if (colon < 0) continue;
      const field = line.slice(0, colon).trim().toLowerCase();
      const value = line.slice(colon + 1).trim();
      if (field === 'user-agent') {
        if (!group || hasRules) { group = { agents: [], rules: [] }; groups.push(group); hasRules = false; }
        const agent = value.match(/^[a-z_-]+/i)?.[0].toLowerCase();
        group.agents.push(/^\*(?:\s|$)/.test(value) ? '*' : agent || '');
      } else if (group && (field === 'allow' || field === 'disallow')) {
        hasRules = true;
        if (value) group.rules.push({ allow: field === 'allow', path: normalize(value), line: index + 1 });
      }
    }
    const agent = groups.some(group => group.agents.includes('googlebot')) ? 'googlebot' : '*';
    return groups.filter(group => group.agents.includes(agent)).flatMap(group => group.rules);
  }

  function matches(path, pattern) {
    // Literal segments avoid regular-expression backtracking on untrusted rules.
    const anchored = pattern.endsWith('$');
    const parts = (anchored ? pattern.slice(0, -1) : pattern).split('*');
    if (!path.startsWith(parts[0])) return false;
    let end = parts[0].length;
    if (parts.length === 1) return !anchored || end === path.length;
    for (let i = 1; i < parts.length; i++) {
      const part = parts[i];
      if (anchored && i === parts.length - 1) return path.endsWith(part) && path.length - part.length >= end;
      const start = path.indexOf(part, end);
      if (start < 0) return false;
      end = start + part.length;
    }
    return true;
  }

  function evaluate(rules, url) {
    const address = new URL(url);
    const path = normalize(address.pathname + address.search);
    let rule = null;
    for (const candidate of rules) {
      if (rule && (candidate.path.length < rule.path.length || (candidate.path.length === rule.path.length && !candidate.allow))) continue;
      if (matches(path, candidate.path)) rule = candidate;
    }
    return { state: rule && !rule.allow ? 'blocked' : 'allowed', rule };
  }

  async function readPolicy(url, signal) {
    const controller = new AbortController();
    const abort = () => controller.abort();
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) controller.abort();
    const timer = setTimeout(abort, 10000);
    let reader;
    try {
      const response = await fetch(url, { signal: controller.signal, credentials: 'omit', referrerPolicy: 'no-referrer', cache: 'no-store', redirect: 'follow' });
      const status = response.status;
      if (status >= 400 && status < 500 && status !== 429) {
        response.body?.cancel().catch(() => {});
        return { status, rules: [], missing: true };
      }
      if (!response.ok) {
        response.body?.cancel().catch(() => {});
        return { status, error: `robots.txt returned HTTP ${status}` };
      }
      const decoder = new TextDecoder('utf-8');
      let text = '', bytes = 0;
      reader = response.body?.getReader();
      if (reader) {
        while (bytes < MAX_BYTES) {
          const { done, value } = await reader.read();
          if (done) break;
          const part = value.subarray(0, MAX_BYTES - bytes);
          bytes += part.byteLength;
          text += decoder.decode(part, { stream: true });
        }
      }
      text += decoder.decode();
      return { status, rules: parse(text), limited: bytes === MAX_BYTES };
    } catch (error) {
      return { error: controller.signal.aborted ? 'robots.txt request timed out or was stopped' : 'the browser could not read robots.txt (network or access restriction)' };
    } finally {
      reader?.cancel().catch(() => {});
      clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
    }
  }

  function createChecker() {
    const policies = new Map();
    return {
      async check(url, { signal } = {}) {
        const robotsURL = new URL('/robots.txt', url).href;
        if (!policies.has(robotsURL)) policies.set(robotsURL, readPolicy(robotsURL, signal));
        const policy = await policies.get(robotsURL);
        // Stopping a batch must not poison the next batch's shared request.
        if (signal?.aborted) policies.delete(robotsURL);
        const { rules, ...metadata } = policy;
        return { robotsURL, ...metadata, ...(policy.error ? { state: 'unknown' } : evaluate(rules, url)) };
      }
    };
  }

  function annotate(result, robots) {
    result.robots = robots;
    if (robots.state === 'blocked') result.notes.push(`Warning: Googlebot blocked by robots.txt: Disallow: ${robots.rule.path} (line ${robots.rule.line}).`);
    if (robots.state === 'unknown') {
      result.notes.push(`Googlebot robots.txt check incomplete: ${robots.error}.`);
      result.incomplete = true;
    }
    return result;
  }
  globalThis.__prettySitemapRobots = Object.freeze({ parse, evaluate, createChecker, annotate, MAX_BYTES });
})();
