(async () => {
  'use strict';
  if (globalThis.__prettySitemapRendered && document.documentElement.id === 'pretty-sitemap') {
    return { status: 'already' };
  }
  delete globalThis.__prettySitemapRequestedSource;
  const pageUrl = location.href;
  if (!['https:', 'http:'].includes(location.protocol)) return { status: 'unsupported' };
  try {
    // Read the original XML again: Chrome has replaced it with HTML after XSLT.
    const response = await fetch(pageUrl, {
      credentials: 'same-origin', redirect: 'error', signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) return { status: 'unavailable' };
    const type = response.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
    if (!['application/xml', 'text/xml'].includes(type)) return { status: 'not-sitemap' };
    const xml = new DOMParser().parseFromString(await response.text(), 'application/xml');
    const source = xml.documentElement;
    if (location.href !== pageUrl) return { status: 'changed' };
    if (xml.getElementsByTagName('parsererror').length ||
        source.namespaceURI !== 'http://www.sitemaps.org/schemas/sitemap/0.9' ||
        !['urlset', 'sitemapindex'].includes(source.localName)) return { status: 'not-sitemap' };
    globalThis.__prettySitemapRequestedSource = source;
    return { status: 'ready' };
  } catch {
    return { status: 'unavailable' };
  }
})();
